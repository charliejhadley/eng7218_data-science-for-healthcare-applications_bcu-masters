ENG7218 Example Coursework (for 2022)
================
2022-08-09

This repository is designed to show you the structure that your
assessment must take.

The repository has been made into a template to make replicating the
structure of the report easier.
