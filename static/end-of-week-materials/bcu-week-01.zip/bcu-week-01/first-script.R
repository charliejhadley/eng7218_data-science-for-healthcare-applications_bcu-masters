library(ggplot2)
library(praise)
# This is a comment
praise()

geom

2 + 3

rep("parrots", 5)


islands[2]

iris$

