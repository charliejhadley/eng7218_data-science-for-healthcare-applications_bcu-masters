
Download R - https://cran.r-project.org/

https://r4ds.had.co.nz/


https://www.rstudio.com/products/rstudio/download/




https://eng7218.netlify.app

https://github.com/charliejhadley/eng7218_2022_example-coursework

https://flowingdata.com/2015/12/15/a-day-in-the-life-of-americans/

Kenneth  

javairia

Kelvin

Ceren

Stelin

Heba

Charlotte


https://github.com/charliejhadley/eng7218_2022_example-coursework



==============================================================================
GETTING TO KNOW YOU (CODE
==============================================================================


====
HAVE YOU EVER WRITTEN CODE BEFORE?

no 
yes
yes
no
Yes
yes

====
WHICH LANGUAGES HAVE YOU WRITTEN IN?

c++
N/A
C++ and Python
C++

c++

====
HAVE YOU MADE DATA VISUALISATIONS BEFORE?





====
WHAT TOOLS HAVE YOU USED TO BUILD DATAVIZ?



======
library(ggplot2)
library(praise)
# This is a comment
praise()

geom

2 + 3

rep("parrots", 5)


islands[2]

iris$







